# VidWink Frontend
A simple Vite + React frontend for VidWink.